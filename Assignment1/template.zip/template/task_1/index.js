'use strict';

const express = require('express');

const app = express();



app.get('/', (req, res) => {
	// Send a landing page back to the user
});


// The rest of the routes goes here


app.listen(3000);
